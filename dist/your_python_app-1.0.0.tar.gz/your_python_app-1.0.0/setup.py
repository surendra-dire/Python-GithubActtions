from setuptools import setup, find_packages

setup(
    name="your-python-app",
    version="1.0.0",
    packages=find_packages(),
    install_requires=[
        # List of dependencies
        'requests',
    ],
)
